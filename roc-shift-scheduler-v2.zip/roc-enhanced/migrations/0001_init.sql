-- ROC Shift Scheduler — Enhanced Schema v2
-- Cloudflare D1 (SQLite-compatible)

-- ─── Core tables ──────────────────────────────────────────────────────────────

CREATE TABLE departments (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  day_min    INTEGER NOT NULL,
  night_min  INTEGER NOT NULL,
  day_code   TEXT NOT NULL,
  night_code TEXT NOT NULL
);

CREATE TABLE staff (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  department_id TEXT NOT NULL REFERENCES departments(id),
  email         TEXT,
  role          TEXT NOT NULL DEFAULT 'staff', -- 'admin' | 'supervisor' | 'staff'
  active        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ─── Leave workflow ───────────────────────────────────────────────────────────

CREATE TABLE leave_requests (
  id             TEXT PRIMARY KEY,
  staff_id       TEXT NOT NULL REFERENCES staff(id),
  date           TEXT NOT NULL,          -- YYYY-MM-DD
  leave_type     TEXT NOT NULL DEFAULT 'annual', -- 'annual' | 'sick' | 'emergency' | 'unpaid' | 'maternity' | 'paternity'
  reason         TEXT,
  status         TEXT NOT NULL DEFAULT 'pending', -- 'pending' | 'approved' | 'rejected'
  reviewed_by    TEXT REFERENCES staff(id),
  review_note    TEXT,
  requested_at   TEXT NOT NULL DEFAULT (datetime('now')),
  reviewed_at    TEXT
);

CREATE UNIQUE INDEX idx_leave_staff_date ON leave_requests(staff_id, date);
CREATE INDEX idx_leave_status ON leave_requests(status);
CREATE INDEX idx_leave_date ON leave_requests(date);

-- ─── Schedules ────────────────────────────────────────────────────────────────

CREATE TABLE schedules (
  id             TEXT PRIMARY KEY,
  month          TEXT NOT NULL,       -- YYYY-MM
  department_id  TEXT NOT NULL REFERENCES departments(id),
  generated_at   TEXT NOT NULL,
  published_at   TEXT,
  status         TEXT NOT NULL DEFAULT 'draft', -- 'draft' | 'published' | 'archived'
  notes          TEXT,
  generator_ver  TEXT NOT NULL DEFAULT '2.0'
);

CREATE INDEX idx_sched_month_dept ON schedules(month, department_id);

CREATE TABLE shift_assignments (
  id                TEXT PRIMARY KEY,
  schedule_id       TEXT NOT NULL REFERENCES schedules(id),
  staff_id          TEXT NOT NULL REFERENCES staff(id),
  date              TEXT NOT NULL,    -- YYYY-MM-DD
  shift_code        TEXT NOT NULL,
  is_manual_override INTEGER NOT NULL DEFAULT 0,
  override_by       TEXT REFERENCES staff(id),
  override_at       TEXT,
  override_reason   TEXT
);

CREATE UNIQUE INDEX idx_assign_unique    ON shift_assignments(schedule_id, staff_id, date);
CREATE INDEX       idx_assign_schedule   ON shift_assignments(schedule_id);
CREATE INDEX       idx_assign_staff      ON shift_assignments(staff_id);

-- ─── Shift swap requests ──────────────────────────────────────────────────────

CREATE TABLE swap_requests (
  id              TEXT PRIMARY KEY,
  requester_id    TEXT NOT NULL REFERENCES staff(id),
  target_id       TEXT NOT NULL REFERENCES staff(id),
  schedule_id     TEXT NOT NULL REFERENCES schedules(id),
  requester_date  TEXT NOT NULL,
  target_date     TEXT NOT NULL,
  reason          TEXT,
  status          TEXT NOT NULL DEFAULT 'pending', -- 'pending' | 'accepted' | 'rejected' | 'approved' | 'cancelled'
  target_response TEXT,
  admin_note      TEXT,
  reviewed_by     TEXT REFERENCES staff(id),
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_swap_requester ON swap_requests(requester_id);
CREATE INDEX idx_swap_target    ON swap_requests(target_id);
CREATE INDEX idx_swap_status    ON swap_requests(status);

-- ─── Audit log ────────────────────────────────────────────────────────────────

CREATE TABLE audit_log (
  id          TEXT PRIMARY KEY,
  actor_id    TEXT,                    -- staff_id who made the change (NULL = system)
  action      TEXT NOT NULL,           -- e.g. 'leave.approved', 'schedule.published', 'shift.override'
  entity_type TEXT NOT NULL,           -- 'leave' | 'schedule' | 'shift' | 'swap' | 'staff'
  entity_id   TEXT,
  payload     TEXT,                    -- JSON
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id);
CREATE INDEX idx_audit_ts     ON audit_log(created_at);

-- ─── Notifications ────────────────────────────────────────────────────────────

CREATE TABLE notifications (
  id          TEXT PRIMARY KEY,
  staff_id    TEXT NOT NULL REFERENCES staff(id),
  type        TEXT NOT NULL,    -- 'leave_pending' | 'leave_approved' | 'leave_rejected' | 'swap_request' | 'swap_result' | 'schedule_published'
  message     TEXT NOT NULL,
  link        TEXT,
  is_read     INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX idx_notif_staff ON notifications(staff_id, is_read);

-- ─── Seed data ───────────────────────────────────────────────────────────────

INSERT INTO departments (id, name, day_min, night_min, day_code, night_code) VALUES
  ('ISOC', 'ISOC',          3, 3, 'D',  'N'),
  ('SCE',  'SCE/SCM Desk',  2, 1, 'DC', 'NC');

INSERT INTO staff (id, name, department_id, role) VALUES
  ('admin',    'Admin',    'ISOC', 'admin'),
  ('stephen',  'Stephen',  'ISOC', 'supervisor'),
  ('charles',  'Charles',  'ISOC', 'staff'),
  ('daisy',    'Daisy',    'ISOC', 'staff'),
  ('tabitha',  'Tabitha',  'ISOC', 'staff'),
  ('eugene',   'Eugene',   'ISOC', 'staff'),
  ('wayne',    'Wayne',    'ISOC', 'staff'),
  ('benson',   'Benson',   'ISOC', 'staff'),
  ('osewe',    'Osewe',    'ISOC', 'staff'),
  ('hilda',    'Hilda',    'ISOC', 'staff'),
  ('joan',     'Joan',     'ISOC', 'staff'),
  ('murad',    'Murad',    'SCE',  'supervisor'),
  ('david',    'David',    'SCE',  'staff'),
  ('griffin',  'Griffin',  'SCE',  'staff'),
  ('chebet',   'Chebet',   'SCE',  'staff'),
  ('moreen',   'Moreen',   'SCE',  'staff');
