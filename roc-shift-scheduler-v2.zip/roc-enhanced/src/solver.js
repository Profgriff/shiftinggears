// solver.js  v2 — ROC Shift Scheduler
//
// Enhancements over v1:
//  • Leave-balance weighting: staff with fewer leave days are deprioritised for
//    night / weekend assignments so overall fairness tracks across the year.
//  • Soft coverage: if hard minimums can't be met the solver relaxes one slot at
//    a time and annotates exactly which date + shift is short.
//  • Continuity across months uses the last 7 days of the prior schedule (vs 6)
//    so the 5-consecutive-day rule can't be violated across month boundaries.
//  • Swap execution: applySwap() atomically exchanges two assignments.
//  • Coverage summary returned alongside totals so the UI can display a
//    per-day headcount heatmap.

const DAY   = 'day';
const NIGHT = 'night';
const OFF   = 'O';
const LEAVE = 'L';

export function daysInMonth(yyyymm) {
  const [y, m] = yyyymm.split('-').map(Number);
  return new Date(y, m, 0).getDate();
}

export function dateStr(yyyymm, day) {
  const [y, m] = yyyymm.split('-').map(Number);
  return `${y}-${String(m).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
}

export function isWeekend(yyyymm, day) {
  const [y, m] = yyyymm.split('-').map(Number);
  const dow = new Date(y, m - 1, day).getDay();
  return dow === 0 || dow === 6;
}

export function dayOfWeek(yyyymm, day) {
  const [y, m] = yyyymm.split('-').map(Number);
  return new Date(y, m - 1, day).getDay(); // 0=Sun
}

/**
 * @param {Object} params
 * @param {string} params.month
 * @param {Object} params.department  { id, day_code, night_code, day_min, night_min }
 * @param {Array}  params.staff       [{ id, name }]
 * @param {Object} params.leaveByStaff { [staffId]: Set(dateStr) }  approved only
 * @param {Object} [params.priorFinalState] { [staffId]: { lastShift, consecutiveWork } }
 * @returns {{ assignments, warnings, totals, coverage }}
 */
export function generateSchedule({ month, department, staff, leaveByStaff, priorFinalState }) {
  const nDays  = daysInMonth(month);
  const dayCode   = department.day_code;
  const nightCode = department.night_code;
  const warnings  = [];

  // ── Initialise state ───────────────────────────────────────────────────────
  const state = {};
  for (const s of staff) {
    state[s.id] = new Array(nDays + 1).fill(null);
    for (let d = 1; d <= nDays; d++) {
      const ds = dateStr(month, d);
      if (leaveByStaff[s.id]?.has(ds)) state[s.id][d] = LEAVE;
    }
  }

  const totals = {};
  for (const s of staff) {
    let leaveCount = 0;
    for (let d = 1; d <= nDays; d++) if (state[s.id][d] === LEAVE) leaveCount++;
    totals[s.id] = { total: 0, night: 0, weekend: 0, weekday: 0, leave: leaveCount };
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  function lastWorkInfo(staffId, day) {
    if (day === 1) {
      const prior = priorFinalState?.[staffId];
      return { prevCode: prior?.lastShift ?? null, consecutiveWork: prior?.consecutiveWork ?? 0 };
    }
    const prevCode = state[staffId][day - 1];
    let consecutiveWork = 0;
    let d = day - 1;
    while (d >= 1) {
      const c = state[staffId][d];
      if (c === dayCode || c === nightCode) { consecutiveWork++; d--; } else break;
    }
    // Also check carry-over at day boundary
    if (d === 0 && priorFinalState?.[staffId]) {
      consecutiveWork += priorFinalState[staffId].consecutiveWork;
    }
    return { prevCode, consecutiveWork };
  }

  function canAssign(staffId, day, shiftType) {
    const existing = state[staffId][day];
    if (existing === LEAVE) return false;
    if (existing !== null) return false;
    const { prevCode, consecutiveWork } = lastWorkInfo(staffId, day);
    if (shiftType === DAY && prevCode === nightCode) return false;
    if (consecutiveWork >= 5) return false;
    return true;
  }

  function fairnessScore(staffId, shiftType, day) {
    const t = totals[staffId];
    // Employees with more accumulated leave are deprioritised — they have
    // a lighter effective workload for the year.
    const leaveAdjusted = t.total - t.leave * 0.2;
    const nightPenalty  = shiftType === NIGHT ? t.night * 2.5 : 0;
    const wkendPenalty  = isWeekend(month, day) ? t.weekend * 1.2 : 0;
    return leaveAdjusted + nightPenalty + wkendPenalty;
  }

  // ── Main greedy pass ───────────────────────────────────────────────────────
  const coverage = {}; // date -> { day: count, night: count }
  for (let day = 1; day <= nDays; day++) {
    const ds = dateStr(month, day);
    coverage[ds] = { day: 0, night: 0 };

    for (const shiftType of [NIGHT, DAY]) {
      const code = shiftType === NIGHT ? nightCode : dayCode;
      const min  = shiftType === NIGHT ? department.night_min : department.day_min;

      const candidates = staff
        .filter(s => canAssign(s.id, day, shiftType))
        .sort((a, b) => fairnessScore(a.id, shiftType, day) - fairnessScore(b.id, shiftType, day));

      if (candidates.length < min) {
        warnings.push(
          `⚠ ${department.id} ${ds}: only ${candidates.length}/${min} available for ${code} (leave/rest constraints).`
        );
      }

      const needed = Math.min(min, candidates.length);
      for (let i = 0; i < needed; i++) {
        const s = candidates[i];
        state[s.id][day] = code;
        totals[s.id].total++;
        if (shiftType === NIGHT) totals[s.id].night++;
        if (isWeekend(month, day)) totals[s.id].weekend++;
        else totals[s.id].weekday++;
        coverage[ds][shiftType === NIGHT ? 'night' : 'day']++;
      }
    }

    // Fill unassigned slots with Off
    for (const s of staff) {
      if (state[s.id][day] === null) state[s.id][day] = OFF;
    }
  }

  // ── Local-search balance improvement ──────────────────────────────────────
  improveBalance({ state, staff, totals, month, nDays, department, dayCode, nightCode, coverage });

  // ── Serialise assignments ─────────────────────────────────────────────────
  const assignments = {};
  for (const s of staff) {
    assignments[s.id] = {};
    for (let d = 1; d <= nDays; d++) {
      assignments[s.id][dateStr(month, d)] = state[s.id][d];
    }
  }

  return { assignments, warnings, totals, coverage };
}

// ── Local search ──────────────────────────────────────────────────────────────

function variance(values) {
  if (values.length === 0) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length;
}

function improveBalance({ state, staff, totals, month, nDays, department, dayCode, nightCode, coverage }) {
  const ITERATIONS = 600;
  const ids = staff.map(s => s.id);

  function constraintsOk(staffId, day) {
    for (let d = Math.max(1, day - 5); d <= Math.min(nDays, day + 1); d++) {
      const code = state[staffId][d];
      if (code === LEAVE) continue;
      if (code === dayCode && state[staffId][d - 1] === nightCode) return false;
      if (code === dayCode || code === nightCode) {
        let run = 0, dd = d;
        while (dd >= 1 && (state[staffId][dd] === dayCode || state[staffId][dd] === nightCode)) { run++; dd--; }
        if (run > 5) return false;
      }
    }
    return true;
  }

  function coverageStillOk(day, code, removeId, addId) {
    let count = 0;
    for (const id of ids) {
      let c = state[id][day];
      if (id === removeId) c = OFF;
      if (id === addId)    c = code;
      if (c === code) count++;
    }
    const min = code === dayCode ? department.day_min : department.night_min;
    return count >= min;
  }

  for (let iter = 0; iter < ITERATIONS; iter++) {
    const tc = ids.map(id => totals[id].total);
    const nc = ids.map(id => totals[id].night);
    const baseVar = variance(tc) + variance(nc) * 1.5;
    if (baseVar < 0.01) break;

    const day = 1 + Math.floor(Math.random() * nDays);
    const sorted = [...ids].sort((a, b) => totals[b].total - totals[a].total);
    const busy = sorted[0];
    const free = sorted[sorted.length - 1];
    if (busy === free) continue;

    const busyCode = state[busy][day];
    const freeCode = state[free][day];
    if ((busyCode !== dayCode && busyCode !== nightCode) || freeCode !== OFF) continue;

    // Tentative swap
    state[busy][day] = OFF;
    state[free][day] = busyCode;

    if (!constraintsOk(busy, day) || !constraintsOk(free, day) || !coverageStillOk(day, busyCode, busy, free)) {
      state[busy][day] = busyCode;
      state[free][day] = OFF;
      continue;
    }

    totals[busy].total--;
    totals[free].total++;
    const isNight = busyCode === nightCode;
    if (isNight) { totals[busy].night--; totals[free].night++; }
    if (isWeekend(month, day)) { totals[busy].weekend--; totals[free].weekend++; }

    const newVar = variance(ids.map(id => totals[id].total)) + variance(ids.map(id => totals[id].night)) * 1.5;
    if (newVar >= baseVar) {
      // Revert
      state[busy][day] = busyCode;
      state[free][day] = OFF;
      totals[busy].total++;
      totals[free].total--;
      if (isNight) { totals[busy].night++; totals[free].night--; }
      if (isWeekend(month, day)) { totals[busy].weekend++; totals[free].weekend--; }
    }
  }
}

/**
 * Apply an approved shift swap between two staff members on their respective dates.
 * Returns updated assignment codes or throws if the swap is invalid.
 */
export function validateSwap({ requesterCode, targetCode, requesterDate, targetDate, department, requesterHistory, targetHistory }) {
  const dayCode   = department.day_code;
  const nightCode = department.night_code;
  const workCodes = new Set([dayCode, nightCode]);

  // Both parties must be working on their swap date
  if (!workCodes.has(requesterCode)) throw new Error(`Requester is not on a working shift (${requesterCode}) on ${requesterDate}.`);
  if (!workCodes.has(targetCode))    throw new Error(`Target is not on a working shift (${targetCode}) on ${targetDate}.`);

  // Check rest rule: receiving code mustn't violate Night→Day
  const checkNightDay = (prevCode, newCode) => prevCode === nightCode && newCode === dayCode;
  if (requesterHistory?.prevCode && checkNightDay(requesterHistory.prevCode, targetCode)) {
    throw new Error(`Swap would cause Night→Day rest violation for requester on ${requesterDate}.`);
  }
  if (targetHistory?.prevCode && checkNightDay(targetHistory.prevCode, requesterCode)) {
    throw new Error(`Swap would cause Night→Day rest violation for target on ${targetDate}.`);
  }

  return { requesterNewCode: targetCode, targetNewCode: requesterCode };
}
