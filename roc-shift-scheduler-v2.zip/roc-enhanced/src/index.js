// src/index.js  v2 — ROC Shift Scheduler (Enhanced)
//
// New endpoints vs v1:
//   PATCH  /api/leave/:id/review            { status, review_note, reviewer_id }
//   GET    /api/leave/pending               list pending leave requests
//   GET    /api/staff/:id                   single staff record
//   PATCH  /api/staff/:id                   update name / role / email / active
//   DELETE /api/staff/:id                   deactivate staff
//   GET    /api/analytics?month=&dept=      coverage heatmap + fairness stats
//   GET    /api/notifications?staff_id=     unread notifications
//   PATCH  /api/notifications/:id/read      mark notification read
//   POST   /api/swaps                       create swap request  { requester_id, target_id, schedule_id, requester_date, target_date, reason }
//   PATCH  /api/swaps/:id/respond           target accepts/rejects  { accepted: bool, response: string }
//   PATCH  /api/swaps/:id/approve           admin finalises  { approved: bool, note, reviewer_id }
//   GET    /api/swaps?staff_id=&status=     list swaps
//   GET    /api/audit?entity_type=&entity_id=&limit=   audit trail

import { generateSchedule, daysInMonth, dateStr, isWeekend, validateSwap } from './solver.js';

function json(data, init = {}) {
  return new Response(JSON.stringify(data), {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(init.headers || {}) },
  });
}

function uuid() { return crypto.randomUUID(); }

async function audit(db, actor_id, action, entity_type, entity_id, payload) {
  await db.prepare(
    'INSERT INTO audit_log (id, actor_id, action, entity_type, entity_id, payload, created_at) VALUES (?,?,?,?,?,?,?)'
  ).bind(uuid(), actor_id ?? null, action, entity_type, entity_id ?? null, JSON.stringify(payload ?? {}), new Date().toISOString()).run();
}

async function notify(db, staff_id, type, message, link) {
  await db.prepare(
    'INSERT INTO notifications (id, staff_id, type, message, link, created_at) VALUES (?,?,?,?,?,?)'
  ).bind(uuid(), staff_id, type, message, link ?? null, new Date().toISOString()).run();
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const { pathname } = url;

    try {
      if (!pathname.startsWith('/api/')) return env.ASSETS.fetch(request);

      // ── Departments ─────────────────────────────────────────────────────────
      if (pathname === '/api/departments' && request.method === 'GET') {
        const { results } = await env.DB.prepare('SELECT * FROM departments').all();
        return json(results);
      }

      if (pathname === '/api/departments' && request.method === 'POST') {
        const body = await request.json();
        const { id, name, day_min, night_min, day_code, night_code } = body;
        await env.DB.prepare(
          'INSERT INTO departments (id,name,day_min,night_min,day_code,night_code) VALUES (?,?,?,?,?,?)'
        ).bind(id, name, day_min, night_min, day_code, night_code).run();
        await audit(env.DB, null, 'department.created', 'department', id, body);
        return json({ id }, { status: 201 });
      }

      // ── Staff ───────────────────────────────────────────────────────────────
      if (pathname === '/api/staff' && request.method === 'GET') {
        const dept = url.searchParams.get('department');
        const stmt = dept
          ? env.DB.prepare('SELECT * FROM staff WHERE department_id=? AND active=1 ORDER BY name').bind(dept)
          : env.DB.prepare('SELECT * FROM staff WHERE active=1 ORDER BY department_id,name');
        const { results } = await stmt.all();
        return json(results);
      }

      if (pathname === '/api/staff' && request.method === 'POST') {
        const body = await request.json();
        const id = body.id || body.name.toLowerCase().replace(/\s+/g, '-');
        await env.DB.prepare(
          'INSERT INTO staff (id,name,department_id,email,role,active) VALUES (?,?,?,?,?,1)'
        ).bind(id, body.name, body.department_id, body.email ?? null, body.role ?? 'staff').run();
        await audit(env.DB, body.actor_id, 'staff.created', 'staff', id, body);
        return json({ id, name: body.name, department_id: body.department_id }, { status: 201 });
      }

      const staffOneMatch = pathname.match(/^\/api\/staff\/([^/]+)$/);
      if (staffOneMatch) {
        const id = staffOneMatch[1];

        if (request.method === 'GET') {
          const row = await env.DB.prepare('SELECT * FROM staff WHERE id=?').bind(id).first();
          if (!row) return json({ error: 'not found' }, { status: 404 });
          return json(row);
        }

        if (request.method === 'PATCH') {
          const body = await request.json();
          const fields = [];
          const vals   = [];
          for (const f of ['name','email','role','active','department_id']) {
            if (body[f] !== undefined) { fields.push(`${f}=?`); vals.push(body[f]); }
          }
          if (!fields.length) return json({ error: 'nothing to update' }, { status: 400 });
          vals.push(id);
          await env.DB.prepare(`UPDATE staff SET ${fields.join(',')} WHERE id=?`).bind(...vals).run();
          await audit(env.DB, body.actor_id, 'staff.updated', 'staff', id, body);
          return json({ updated: true });
        }

        if (request.method === 'DELETE') {
          await env.DB.prepare("UPDATE staff SET active=0 WHERE id=?").bind(id).run();
          await audit(env.DB, null, 'staff.deactivated', 'staff', id, {});
          return json({ deactivated: true });
        }
      }

      // ── Leave ───────────────────────────────────────────────────────────────
      if (pathname === '/api/leave/pending' && request.method === 'GET') {
        const dept = url.searchParams.get('department');
        let q = `SELECT lr.*, s.name AS staff_name, s.department_id
                 FROM leave_requests lr JOIN staff s ON s.id=lr.staff_id
                 WHERE lr.status='pending'`;
        const binds = [];
        if (dept) { q += ' AND s.department_id=?'; binds.push(dept); }
        q += ' ORDER BY lr.requested_at';
        const { results } = await env.DB.prepare(q).bind(...binds).all();
        return json(results);
      }

      if (pathname === '/api/leave' && request.method === 'GET') {
        const staffId = url.searchParams.get('staff_id');
        const month   = url.searchParams.get('month');
        const status  = url.searchParams.get('status');
        let q = `SELECT lr.*, s.name AS staff_name FROM leave_requests lr JOIN staff s ON s.id=lr.staff_id WHERE 1=1`;
        const binds = [];
        if (staffId) { q += ' AND lr.staff_id=?';    binds.push(staffId); }
        if (month)   { q += ' AND lr.date LIKE ?';   binds.push(`${month}-%`); }
        if (status)  { q += ' AND lr.status=?';      binds.push(status); }
        q += ' ORDER BY lr.date';
        const { results } = await env.DB.prepare(q).bind(...binds).all();
        return json(results);
      }

      if (pathname === '/api/leave' && request.method === 'POST') {
        const body = await request.json();
        const id   = uuid();
        const status = body.status || 'pending';
        await env.DB.prepare(
          `INSERT INTO leave_requests (id,staff_id,date,leave_type,reason,status,requested_at)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(staff_id,date) DO UPDATE SET status=excluded.status, leave_type=excluded.leave_type, reason=excluded.reason`
        ).bind(id, body.staff_id, body.date, body.leave_type ?? 'annual', body.reason ?? null, status, new Date().toISOString()).run();

        await audit(env.DB, body.staff_id, 'leave.requested', 'leave', id, body);

        // Notify admins if pending
        if (status === 'pending') {
          const { results: admins } = await env.DB.prepare(
            "SELECT id FROM staff WHERE role IN ('admin','supervisor') AND active=1"
          ).all();
          const staffRow = await env.DB.prepare('SELECT name FROM staff WHERE id=?').bind(body.staff_id).first();
          for (const a of admins) {
            await notify(env.DB, a.id, 'leave_pending',
              `${staffRow?.name ?? body.staff_id} requested leave on ${body.date} (${body.leave_type ?? 'annual'}).`,
              `/api/leave/${id}`);
          }
        }

        return json({ id, ...body, status }, { status: 201 });
      }

      // Leave review (approve / reject)
      const leaveReviewMatch = pathname.match(/^\/api\/leave\/([^/]+)\/review$/);
      if (leaveReviewMatch && request.method === 'PATCH') {
        const leaveId = leaveReviewMatch[1];
        const body    = await request.json();
        const { status, review_note, reviewer_id } = body;
        if (!['approved','rejected'].includes(status)) {
          return json({ error: "status must be 'approved' or 'rejected'" }, { status: 400 });
        }
        const now = new Date().toISOString();
        await env.DB.prepare(
          `UPDATE leave_requests SET status=?, review_note=?, reviewed_by=?, reviewed_at=? WHERE id=?`
        ).bind(status, review_note ?? null, reviewer_id ?? null, now, leaveId).run();

        const leave = await env.DB.prepare('SELECT * FROM leave_requests WHERE id=?').bind(leaveId).first();
        await audit(env.DB, reviewer_id, `leave.${status}`, 'leave', leaveId, body);

        // Notify requester
        await notify(env.DB, leave.staff_id, status === 'approved' ? 'leave_approved' : 'leave_rejected',
          `Your leave request for ${leave.date} was ${status}.${review_note ? ' Note: ' + review_note : ''}`,
          `/api/leave/${leaveId}`);

        return json({ updated: true, status });
      }

      if (pathname.startsWith('/api/leave/') && request.method === 'DELETE') {
        const id = pathname.split('/').pop();
        await env.DB.prepare('DELETE FROM leave_requests WHERE id=?').bind(id).run();
        await audit(env.DB, null, 'leave.deleted', 'leave', id, {});
        return json({ deleted: true });
      }

      // ── Schedule generation ─────────────────────────────────────────────────
      if (pathname === '/api/schedules/generate' && request.method === 'POST') {
        const body = await request.json();
        const { month, department_id } = body;
        if (!month || !department_id) return json({ error: 'month and department_id required' }, { status: 400 });

        const dept = await env.DB.prepare('SELECT * FROM departments WHERE id=?').bind(department_id).first();
        if (!dept) return json({ error: 'unknown department' }, { status: 404 });

        const { results: staffRows } = await env.DB.prepare(
          'SELECT id,name FROM staff WHERE department_id=? AND active=1 ORDER BY name'
        ).bind(department_id).all();

        // Only approved leave goes to the solver
        const { results: leaveRows } = staffRows.length > 0
          ? await env.DB.prepare(
              `SELECT staff_id,date FROM leave_requests
               WHERE date LIKE ? AND status='approved' AND staff_id IN (${staffRows.map(() => '?').join(',')})`
            ).bind(`${month}-%`, ...staffRows.map(s => s.id)).all()
          : { results: [] };

        const leaveByStaff = {};
        for (const s of staffRows) leaveByStaff[s.id] = new Set();
        for (const row of leaveRows) leaveByStaff[row.staff_id].add(row.date);

        const priorFinalState = await getPriorFinalState(env.DB, month, department_id, staffRows, dept);

        const { assignments, warnings, totals, coverage } = generateSchedule({
          month, department: dept, staff: staffRows, leaveByStaff, priorFinalState,
        });

        const scheduleId = uuid();
        const now = new Date().toISOString();
        await env.DB.prepare(
          'INSERT INTO schedules (id,month,department_id,generated_at,status,notes) VALUES (?,?,?,?,?,?)'
        ).bind(scheduleId, month, department_id, now, 'draft',
          `Auto-generated for ${department_id}. ${warnings.length} warning(s).`).run();

        const inserts = [];
        for (const s of staffRows) {
          for (let d = 1; d <= daysInMonth(month); d++) {
            const ds = dateStr(month, d);
            inserts.push(
              env.DB.prepare(
                'INSERT INTO shift_assignments (id,schedule_id,staff_id,date,shift_code,is_manual_override) VALUES (?,?,?,?,?,0)'
              ).bind(uuid(), scheduleId, s.id, ds, assignments[s.id][ds])
            );
          }
        }
        await env.DB.batch(inserts);
        await audit(env.DB, body.actor_id, 'schedule.generated', 'schedule', scheduleId, { month, department_id });

        return json({ schedule_id: scheduleId, month, department_id, assignments, totals, warnings, coverage }, { status: 201 });
      }

      // ── List / get schedules ────────────────────────────────────────────────
      if (pathname === '/api/schedules' && request.method === 'GET') {
        const month  = url.searchParams.get('month');
        const dept   = url.searchParams.get('department');
        let q = 'SELECT * FROM schedules WHERE 1=1';
        const binds = [];
        if (month) { q += ' AND month=?';         binds.push(month); }
        if (dept)  { q += ' AND department_id=?'; binds.push(dept); }
        q += ' ORDER BY generated_at DESC';
        const { results } = await env.DB.prepare(q).bind(...binds).all();
        return json(results);
      }

      const schedMatch = pathname.match(/^\/api\/schedules\/([^/]+)$/);
      if (schedMatch && request.method === 'GET') {
        const id = schedMatch[1];
        const schedule = await env.DB.prepare('SELECT * FROM schedules WHERE id=?').bind(id).first();
        if (!schedule) return json({ error: 'not found' }, { status: 404 });
        const { results: assignments } = await env.DB.prepare(
          `SELECT sa.staff_id, st.name AS staff_name, st.department_id, sa.date, sa.shift_code, sa.is_manual_override, sa.override_reason
           FROM shift_assignments sa JOIN staff st ON st.id=sa.staff_id
           WHERE sa.schedule_id=?
           ORDER BY st.name, sa.date`
        ).bind(id).all();
        return json({ ...schedule, assignments });
      }

      // ── Manual assignment override ──────────────────────────────────────────
      const patchMatch = pathname.match(/^\/api\/schedules\/([^/]+)\/assignment$/);
      if (patchMatch && request.method === 'PATCH') {
        const scheduleId = patchMatch[1];
        const body = await request.json();
        const { staff_id, date, shift_code, actor_id, reason } = body;
        const validCodes = ['D','N','DC','NC','O','L'];
        if (!validCodes.includes(shift_code)) {
          return json({ error: `invalid shift_code; must be one of ${validCodes.join(', ')}` }, { status: 400 });
        }
        const now = new Date().toISOString();
        await env.DB.prepare(
          `UPDATE shift_assignments SET shift_code=?, is_manual_override=1, override_by=?, override_at=?, override_reason=?
           WHERE schedule_id=? AND staff_id=? AND date=?`
        ).bind(shift_code, actor_id ?? null, now, reason ?? null, scheduleId, staff_id, date).run();
        await audit(env.DB, actor_id, 'shift.override', 'shift', null, { scheduleId, staff_id, date, shift_code, reason });
        return json({ updated: true });
      }

      // ── Publish ─────────────────────────────────────────────────────────────
      const pubMatch = pathname.match(/^\/api\/schedules\/([^/]+)\/publish$/);
      if (pubMatch && request.method === 'POST') {
        const id = pubMatch[1];
        const body = await request.json().catch(() => ({}));
        const now = new Date().toISOString();
        await env.DB.prepare("UPDATE schedules SET status='published', published_at=? WHERE id=?").bind(now, id).run();
        await audit(env.DB, body.actor_id, 'schedule.published', 'schedule', id, {});

        // Notify all active staff in the department
        const sched = await env.DB.prepare('SELECT * FROM schedules WHERE id=?').bind(id).first();
        if (sched) {
          const { results: staffList } = await env.DB.prepare(
            'SELECT id FROM staff WHERE department_id=? AND active=1'
          ).bind(sched.department_id).all();
          for (const s of staffList) {
            await notify(env.DB, s.id, 'schedule_published',
              `The ${sched.department_id} schedule for ${sched.month} has been published.`, null);
          }
        }
        return json({ published: true });
      }

      // ── Export CSV ──────────────────────────────────────────────────────────
      const expMatch = pathname.match(/^\/api\/schedules\/([^/]+)\/export$/);
      if (expMatch && request.method === 'GET') {
        const id = expMatch[1];
        const schedule = await env.DB.prepare('SELECT * FROM schedules WHERE id=?').bind(id).first();
        if (!schedule) return json({ error: 'not found' }, { status: 404 });
        const { results: assignments } = await env.DB.prepare(
          `SELECT sa.staff_id, st.name AS staff_name, st.department_id, sa.date, sa.shift_code
           FROM shift_assignments sa JOIN staff st ON st.id=sa.staff_id
           WHERE sa.schedule_id=? ORDER BY st.name, sa.date`
        ).bind(id).all();
        const csv = buildCsv(assignments, schedule.month);
        return new Response(csv, {
          headers: {
            'Content-Type': 'text/csv',
            'Content-Disposition': `attachment; filename="roc_schedule_${schedule.month}_${schedule.department_id}.csv"`,
          },
        });
      }

      // ── Analytics ───────────────────────────────────────────────────────────
      if (pathname === '/api/analytics' && request.method === 'GET') {
        const month = url.searchParams.get('month');
        const dept  = url.searchParams.get('department');
        if (!month || !dept) return json({ error: 'month and department required' }, { status: 400 });

        // Latest published or draft schedule
        const sched = await env.DB.prepare(
          "SELECT id FROM schedules WHERE month=? AND department_id=? ORDER BY status DESC, generated_at DESC LIMIT 1"
        ).bind(month, dept).first();

        if (!sched) return json({ coverage: {}, fairness: [], warnings: [] });

        const { results: assignments } = await env.DB.prepare(
          `SELECT sa.staff_id, st.name, sa.date, sa.shift_code
           FROM shift_assignments sa JOIN staff st ON st.id=sa.staff_id
           WHERE sa.schedule_id=?`
        ).bind(sched.id).all();

        const deptRow = await env.DB.prepare('SELECT * FROM departments WHERE id=?').bind(dept).first();
        const nDays   = daysInMonth(month);

        // Coverage heatmap
        const coverage = {};
        for (let d = 1; d <= nDays; d++) {
          const ds = dateStr(month, d);
          coverage[ds] = { day: 0, night: 0, min_day: deptRow.day_min, min_night: deptRow.night_min };
        }

        const fairness = {};
        for (const row of assignments) {
          if (!fairness[row.staff_id]) fairness[row.staff_id] = { name: row.name, total: 0, night: 0, weekend: 0, leave: 0 };
          if (row.shift_code === deptRow.day_code)   { fairness[row.staff_id].total++; coverage[row.date].day++; if (isWeekend(month, parseInt(row.date.slice(8)))) fairness[row.staff_id].weekend++; }
          if (row.shift_code === deptRow.night_code) { fairness[row.staff_id].total++; fairness[row.staff_id].night++; coverage[row.date].night++; if (isWeekend(month, parseInt(row.date.slice(8)))) fairness[row.staff_id].weekend++; }
          if (row.shift_code === 'L') fairness[row.staff_id].leave++;
        }

        // Coverage warnings
        const warnings = [];
        for (const [ds, c] of Object.entries(coverage)) {
          if (c.day   < c.min_day)   warnings.push(`${ds}: day coverage ${c.day}/${c.min_day}`);
          if (c.night < c.min_night) warnings.push(`${ds}: night coverage ${c.night}/${c.min_night}`);
        }

        return json({ coverage, fairness: Object.values(fairness), warnings, schedule_id: sched.id });
      }

      // ── Notifications ───────────────────────────────────────────────────────
      if (pathname === '/api/notifications' && request.method === 'GET') {
        const staffId = url.searchParams.get('staff_id');
        if (!staffId) return json({ error: 'staff_id required' }, { status: 400 });
        const { results } = await env.DB.prepare(
          'SELECT * FROM notifications WHERE staff_id=? ORDER BY created_at DESC LIMIT 50'
        ).bind(staffId).all();
        return json(results);
      }

      const notifMatch = pathname.match(/^\/api\/notifications\/([^/]+)\/read$/);
      if (notifMatch && request.method === 'PATCH') {
        const id = notifMatch[1];
        if (id === 'all') {
          const staffId = url.searchParams.get('staff_id');
          await env.DB.prepare("UPDATE notifications SET is_read=1 WHERE staff_id=?").bind(staffId).run();
        } else {
          await env.DB.prepare("UPDATE notifications SET is_read=1 WHERE id=?").bind(id).run();
        }
        return json({ updated: true });
      }

      // ── Shift swap requests ─────────────────────────────────────────────────
      if (pathname === '/api/swaps' && request.method === 'GET') {
        const staffId = url.searchParams.get('staff_id');
        const status  = url.searchParams.get('status');
        let q = `SELECT sr.*, r.name AS requester_name, t.name AS target_name
                 FROM swap_requests sr
                 JOIN staff r ON r.id=sr.requester_id
                 JOIN staff t ON t.id=sr.target_id WHERE 1=1`;
        const binds = [];
        if (staffId) { q += ' AND (sr.requester_id=? OR sr.target_id=?)'; binds.push(staffId, staffId); }
        if (status)  { q += ' AND sr.status=?'; binds.push(status); }
        q += ' ORDER BY sr.created_at DESC';
        const { results } = await env.DB.prepare(q).bind(...binds).all();
        return json(results);
      }

      if (pathname === '/api/swaps' && request.method === 'POST') {
        const body = await request.json();
        const { requester_id, target_id, schedule_id, requester_date, target_date, reason } = body;

        // Fetch current shift codes for validation
        const reqShift = await env.DB.prepare(
          'SELECT shift_code FROM shift_assignments WHERE schedule_id=? AND staff_id=? AND date=?'
        ).bind(schedule_id, requester_id, requester_date).first();
        const tgtShift = await env.DB.prepare(
          'SELECT shift_code FROM shift_assignments WHERE schedule_id=? AND staff_id=? AND date=?'
        ).bind(schedule_id, target_id, target_date).first();

        if (!reqShift || !tgtShift) return json({ error: 'Could not find assignment records for both parties.' }, { status: 400 });

        const id  = uuid();
        const now = new Date().toISOString();
        await env.DB.prepare(
          `INSERT INTO swap_requests (id,requester_id,target_id,schedule_id,requester_date,target_date,reason,status,created_at,updated_at)
           VALUES (?,?,?,?,?,?,?,'pending',?,?)`
        ).bind(id, requester_id, target_id, schedule_id, requester_date, target_date, reason ?? null, now, now).run();

        await audit(env.DB, requester_id, 'swap.requested', 'swap', id, body);

        // Notify target
        const reqName = (await env.DB.prepare('SELECT name FROM staff WHERE id=?').bind(requester_id).first())?.name ?? requester_id;
        await notify(env.DB, target_id, 'swap_request',
          `${reqName} has requested a shift swap: their ${requester_date} for your ${target_date}.`, null);

        // Notify admins
        const { results: admins } = await env.DB.prepare(
          "SELECT id FROM staff WHERE role IN ('admin','supervisor') AND active=1"
        ).all();
        for (const a of admins) {
          await notify(env.DB, a.id, 'swap_request',
            `New swap request: ${reqName} ↔ ${target_id} (${requester_date} / ${target_date}).`, null);
        }

        return json({ id }, { status: 201 });
      }

      const swapResMatch = pathname.match(/^\/api\/swaps\/([^/]+)\/respond$/);
      if (swapResMatch && request.method === 'PATCH') {
        const id   = swapResMatch[1];
        const body = await request.json();
        const newStatus = body.accepted ? 'accepted' : 'rejected';
        const now = new Date().toISOString();
        await env.DB.prepare(
          `UPDATE swap_requests SET status=?, target_response=?, updated_at=? WHERE id=?`
        ).bind(newStatus, body.response ?? null, now, id).run();

        const swap = await env.DB.prepare('SELECT * FROM swap_requests WHERE id=?').bind(id).first();
        await audit(env.DB, swap.target_id, `swap.${newStatus}`, 'swap', id, body);
        await notify(env.DB, swap.requester_id, 'swap_result',
          `Your swap request was ${newStatus} by the other party.${body.response ? ' Note: ' + body.response : ''}`, null);

        // Notify admins if accepted (needs final approval)
        if (newStatus === 'accepted') {
          const { results: admins } = await env.DB.prepare(
            "SELECT id FROM staff WHERE role IN ('admin','supervisor') AND active=1"
          ).all();
          for (const a of admins) {
            await notify(env.DB, a.id, 'swap_request',
              `Swap request accepted by both parties — awaiting your approval.`, null);
          }
        }

        return json({ updated: true, status: newStatus });
      }

      const swapApprMatch = pathname.match(/^\/api\/swaps\/([^/]+)\/approve$/);
      if (swapApprMatch && request.method === 'PATCH') {
        const id   = swapApprMatch[1];
        const body = await request.json();
        const swap = await env.DB.prepare('SELECT * FROM swap_requests WHERE id=?').bind(id).first();
        if (!swap) return json({ error: 'not found' }, { status: 404 });
        if (swap.status !== 'accepted') return json({ error: 'swap must be accepted by both parties first' }, { status: 409 });

        const now = new Date().toISOString();

        if (!body.approved) {
          await env.DB.prepare(
            `UPDATE swap_requests SET status='rejected', admin_note=?, reviewed_by=?, updated_at=? WHERE id=?`
          ).bind(body.note ?? null, body.reviewer_id ?? null, now, id).run();
          await notify(env.DB, swap.requester_id, 'swap_result', `Your swap was rejected by admin.${body.note ? ' Note: ' + body.note : ''}`, null);
          await notify(env.DB, swap.target_id, 'swap_result', `A swap you were involved in was rejected by admin.`, null);
          return json({ updated: true, status: 'rejected' });
        }

        // Execute the swap — exchange the two shift codes in shift_assignments
        const reqAsgn = await env.DB.prepare(
          'SELECT id,shift_code FROM shift_assignments WHERE schedule_id=? AND staff_id=? AND date=?'
        ).bind(swap.schedule_id, swap.requester_id, swap.requester_date).first();
        const tgtAsgn = await env.DB.prepare(
          'SELECT id,shift_code FROM shift_assignments WHERE schedule_id=? AND staff_id=? AND date=?'
        ).bind(swap.schedule_id, swap.target_id, swap.target_date).first();

        if (!reqAsgn || !tgtAsgn) return json({ error: 'assignment records not found' }, { status: 500 });

        await env.DB.batch([
          env.DB.prepare(`UPDATE shift_assignments SET shift_code=?, is_manual_override=1, override_by=?, override_at=?, override_reason=? WHERE id=?`)
            .bind(tgtAsgn.shift_code, body.reviewer_id ?? null, now, `Swap #${id}`, reqAsgn.id),
          env.DB.prepare(`UPDATE shift_assignments SET shift_code=?, is_manual_override=1, override_by=?, override_at=?, override_reason=? WHERE id=?`)
            .bind(reqAsgn.shift_code, body.reviewer_id ?? null, now, `Swap #${id}`, tgtAsgn.id),
          env.DB.prepare(`UPDATE swap_requests SET status='approved', admin_note=?, reviewed_by=?, updated_at=? WHERE id=?`)
            .bind(body.note ?? null, body.reviewer_id ?? null, now, id),
        ]);

        await audit(env.DB, body.reviewer_id, 'swap.approved', 'swap', id, { swap });
        await notify(env.DB, swap.requester_id, 'swap_result', `Your shift swap was approved and applied.`, null);
        await notify(env.DB, swap.target_id,    'swap_result', `A shift swap you accepted has been approved and applied.`, null);

        return json({ updated: true, status: 'approved' });
      }

      // ── Audit log ────────────────────────────────────────────────────────────
      if (pathname === '/api/audit' && request.method === 'GET') {
        const entityType = url.searchParams.get('entity_type');
        const entityId   = url.searchParams.get('entity_id');
        const limit      = parseInt(url.searchParams.get('limit') || '100');
        let q = 'SELECT * FROM audit_log WHERE 1=1';
        const binds = [];
        if (entityType) { q += ' AND entity_type=?'; binds.push(entityType); }
        if (entityId)   { q += ' AND entity_id=?';   binds.push(entityId); }
        q += ` ORDER BY created_at DESC LIMIT ?`;
        binds.push(limit);
        const { results } = await env.DB.prepare(q).bind(...binds).all();
        return json(results);
      }

      return json({ error: 'not found' }, { status: 404 });

    } catch (err) {
      console.error(err);
      return json({ error: err.message, stack: err.stack }, { status: 500 });
    }
  },
};

// ── Helpers ──────────────────────────────────────────────────────────────────

async function getPriorFinalState(db, month, departmentId, staffRows, dept) {
  const [y, m] = month.split('-').map(Number);
  const prevDate  = new Date(y, m - 2, 1);
  const prevMonth = `${prevDate.getFullYear()}-${String(prevDate.getMonth() + 1).padStart(2,'0')}`;

  const prevSched = await db.prepare(
    "SELECT id FROM schedules WHERE month=? AND department_id=? AND status='published' ORDER BY generated_at DESC LIMIT 1"
  ).bind(prevMonth, departmentId).first();

  if (!prevSched) return null;

  const priorFinalState = {};
  for (const s of staffRows) {
    const { results } = await db.prepare(
      `SELECT date, shift_code FROM shift_assignments
       WHERE schedule_id=? AND staff_id=? ORDER BY date DESC LIMIT 7`
    ).bind(prevSched.id, s.id).all();

    if (!results.length) continue;

    const lastCode = results[0].shift_code;
    let consecutiveWork = 0;
    for (const r of results) {
      if (r.shift_code === dept.day_code || r.shift_code === dept.night_code) consecutiveWork++;
      else break;
    }

    priorFinalState[s.id] = {
      lastShift: lastCode === dept.night_code ? dept.night_code : lastCode === dept.day_code ? dept.day_code : null,
      consecutiveWork,
    };
  }
  return priorFinalState;
}

function buildCsv(assignments, month) {
  const dayCount = daysInMonth(month);
  const byStaff  = {};
  for (const row of assignments) {
    if (!byStaff[row.staff_id]) byStaff[row.staff_id] = { name: row.staff_name, department_id: row.department_id, days: {} };
    byStaff[row.staff_id].days[row.date] = row.shift_code;
  }

  const header = ['Department','Staff', ...Array.from({ length: dayCount }, (_, i) => dateStr(month, i + 1))];
  const lines  = [header.join(',')];
  for (const { name, department_id, days } of Object.values(byStaff)) {
    const row = [department_id, name];
    for (let d = 1; d <= dayCount; d++) row.push(days[dateStr(month, d)] || '');
    lines.push(row.join(','));
  }
  return lines.join('\n');
}
