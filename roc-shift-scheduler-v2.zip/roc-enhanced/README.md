# ROC Shift Scheduler v2 — Enhanced

A production-ready, fully serverless shift scheduling platform built on
**Cloudflare Workers + D1 (SQLite)**. Zero infrastructure to manage —
deploys globally in under a minute.

---

## What's new in v2

| Feature | v1 | v2 |
|---|---|---|
| Auto schedule generation | ✅ | ✅ improved solver |
| Leave requests | basic | Full approval workflow |
| Leave types | — | Annual · Sick · Emergency · Unpaid · Maternity · Paternity |
| Leave balance weighting | — | ✅ fairer night/weekend allocation |
| Shift swap requests | — | ✅ peer accept → admin approve → auto-applied |
| Manual overrides | ✅ | ✅ + reason + audit stamp |
| Schedule publish | — | ✅ notifies all staff |
| Notifications | — | ✅ in-app per user |
| Analytics dashboard | — | ✅ heatmap + fairness bars + gap warnings |
| CSV export | ✅ | ✅ |
| Staff management | basic | Full CRUD + role management |
| Audit trail | — | ✅ every action logged |
| Cross-month continuity | ✅ | ✅ extended (7-day lookback) |
| Solver balance improvement | basic | ✅ 600-iteration local search |
| Coverage soft-failure | — | ✅ warns instead of crashing |

---

## Quick start

```bash
# 1. Install
npm install

# 2. Create the D1 database (one-time)
npx wrangler d1 create roc-scheduler
# → copy the database_id into wrangler.toml

# 3. Apply schema + seed data
npm run db:init

# 4. Run locally
npm run dev
# → http://localhost:8787

# 5. Deploy to production
npm run deploy
```

---

## Project structure

```
roc-enhanced/
├── src/
│   ├── index.js        ← Cloudflare Worker — all API routes
│   └── solver.js       ← Schedule generation + swap validation
├── public/
│   └── index.html      ← Full single-file SPA dashboard
├── migrations/
│   └── 0001_init.sql   ← D1 schema + seed data
├── wrangler.toml
└── package.json
```

---

## API reference

### Departments
| Method | Path | Description |
|---|---|---|
| GET | `/api/departments` | List all departments |
| POST | `/api/departments` | Create department |

### Staff
| Method | Path | Description |
|---|---|---|
| GET | `/api/staff?department=` | List active staff |
| POST | `/api/staff` | Add staff member |
| GET | `/api/staff/:id` | Get single staff |
| PATCH | `/api/staff/:id` | Update name/role/email/dept |
| DELETE | `/api/staff/:id` | Deactivate (soft delete) |

### Leave
| Method | Path | Description |
|---|---|---|
| POST | `/api/leave` | Submit leave request |
| GET | `/api/leave?staff_id=&month=&status=` | Query leave |
| GET | `/api/leave/pending?department=` | Pending approvals only |
| PATCH | `/api/leave/:id/review` | Approve or reject `{ status, review_note, reviewer_id }` |
| DELETE | `/api/leave/:id` | Delete leave entry |

### Schedules
| Method | Path | Description |
|---|---|---|
| POST | `/api/schedules/generate` | Generate schedule `{ month, department_id }` |
| GET | `/api/schedules?month=&department=` | List schedules |
| GET | `/api/schedules/:id` | Get schedule + assignments |
| PATCH | `/api/schedules/:id/assignment` | Manual override `{ staff_id, date, shift_code, reason }` |
| POST | `/api/schedules/:id/publish` | Publish + notify staff |
| GET | `/api/schedules/:id/export` | Download CSV |

### Shift Swaps
| Method | Path | Description |
|---|---|---|
| POST | `/api/swaps` | Create swap request |
| GET | `/api/swaps?staff_id=&status=` | List swaps |
| PATCH | `/api/swaps/:id/respond` | Target accepts/declines `{ accepted, response }` |
| PATCH | `/api/swaps/:id/approve` | Admin approves/rejects + auto-applies `{ approved, note, reviewer_id }` |

### Analytics
| Method | Path | Description |
|---|---|---|
| GET | `/api/analytics?month=&department=` | Coverage heatmap, fairness stats, warnings |

### Notifications
| Method | Path | Description |
|---|---|---|
| GET | `/api/notifications?staff_id=` | Get notifications for user |
| PATCH | `/api/notifications/:id/read` | Mark single notification read |
| PATCH | `/api/notifications/all/read?staff_id=` | Mark all read |

### Audit
| Method | Path | Description |
|---|---|---|
| GET | `/api/audit?entity_type=&entity_id=&limit=` | Query audit log |

---

## Solver logic

The scheduler runs in two passes:

**Pass 1 — Greedy allocation**
1. For each day, iterates night then day shifts (night first to ensure harder-to-fill slots are prioritised).
2. Candidates are filtered by:
   - Not on approved leave
   - Not already assigned that day
   - No Night → Day rest violation (can't follow a night shift with a day shift)
   - No 5-consecutive-day breach (including carry-over from the prior month if published)
3. Candidates are sorted by a **fairness score**: `total_shifts + night_count×2.5 + weekend_count×1.2 - leave_days×0.2`. This naturally rotates who gets nights and weekends without any separate scheduling rules.
4. If fewer candidates are available than the department minimum, the solver assigns all available and emits a warning — it never crashes.

**Pass 2 — Local search balance improvement**
- 600 random swap attempts between the busiest and least-busy staff member for a randomly chosen day.
- Each candidate swap is accepted only if it reduces the combined variance of `total_shifts` and `night_shifts`, and all hard constraints remain satisfied.

**Swap execution**
- When an admin approves a swap, the system atomically exchanges the two `shift_code` values in `shift_assignments` using a D1 batch transaction, and marks both rows as `is_manual_override = 1`.

---

## Roles

| Role | Capabilities |
|---|---|
| `staff` | Request leave, request swaps, view own schedule + notifications |
| `supervisor` | All staff actions + receive leave/swap notifications |
| `admin` | All supervisor actions + approve/reject leave, approve swaps, publish schedules, manage staff, view audit trail |

> In the demo UI, use the **"Acting as"** dropdown in the sidebar to simulate different logged-in users.

---

## Shift codes

| Code | Meaning | Department |
|---|---|---|
| `D` | Day shift | ISOC |
| `N` | Night shift | ISOC |
| `DC` | Day shift | SCE/SCM |
| `NC` | Night shift | SCE/SCM |
| `O` | Off | Both |
| `L` | Leave (approved) | Both |

---

## Extending

**Add a new department:**
```bash
curl -X POST /api/departments \
  -H "Content-Type: application/json" \
  -d '{"id":"NOC","name":"NOC Desk","day_min":2,"night_min":1,"day_code":"ND","night_code":"NN"}'
```

**Customise minimum coverage:**
Update the `day_min` / `night_min` columns in the `departments` table. The solver and analytics heatmap both read these live.

**Multi-day leave (bulk):**
POST one `/api/leave` request per day — the `ON CONFLICT ... DO UPDATE` clause in the SQL makes it idempotent.
